
# FootGenius-AI

Ce projet te permet d’envoyer une question sur un match de foot à l’IA et d’obtenir une prédiction avec style.

## Pour l’utiliser

1. Remplace la clé dans `.env` :
```
OPENAI_API_KEY=ta_clé_openai_ici
```

2. Lance avec :
```
npm install
npm start
```

Tu peux aussi l’utiliser sur Replit ou Vercel.
